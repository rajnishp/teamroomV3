<html>
    <head>
        <meta name="robots" content="noindex" />
        <title>Import Gmail or Google contacts using Google Contacts Data API 3.0 and OAuth 2.0</title>
    <style type="text/css">
		a:link {color:Chocolate;text-decoration: none;}
		a:hover {color:CornflowerBlue;}
		.logo{width:100%;height:110px;border:2px solid black;background-color:#666666;}
    </style>
    </head>
    <body>
        <div class="logo" >
            <a href="http://25labs.com/" >
                <img style="padding-top: 10px;" src="http://25labs.com/wp-content/themes/TheStyle/images/logo.png"></img>
            </a>
        </div>
<br/>
	    <div><b>Visit Tutorial: </b><a style="font-size:17px;" href="http://25labs.com/import-gmail-or-google-contacts-using-google-contacts-data-api-3-0-and-oauth-2-0-in-php/" >Import Gmail or Google contacts using Google Contacts Data API 3.0 and OAuth 2.0 in PHP</a></div>
	        <br/><br/>
        <div align="center" >
        	<a  style="font-size:25px;font-weight:bold;" href="https://accounts.google.com/o/oauth2/auth?client_id=your_client_id_goes_here&redirect_uri=your_redirest_urls_goes_here&scope=https://www.google.com/m8/feeds/&response_type=code">Click here to Import Gmail Contacts</a>
        </div>
    </body>
</html>